// Mock data extending the names/style from the screenshot.
// Sprint = "Kanban Board" universally (matching the data).
// Created by mostly Ebenezer Raja (matching the data).

const ASSIGNEES = [
  { name: "Ebenezer Raja",   short: "Ebenezer", initial: "E", hue: 32  },
  { name: "Dhishan Kudwalli", short: "Dhishan",  initial: "D", hue: 18  },
  { name: "Bhola",           short: "Bhola",    initial: "B", hue: 200 },
  { name: "Mira Chen",       short: "Mira",     initial: "M", hue: 280 },
  { name: "Olu Adeyemi",     short: "Olu",      initial: "O", hue: 95  },
  { name: "Priya Sundar",    short: "Priya",    initial: "P", hue: 340 },
  { name: "Tomoko Sato",     short: "Tomoko",   initial: "T", hue: 55  },
];

const STATUSES = ["Not Now", "Maybe?", "In Progress", "QA", "Bugs", "Ready to Deploy", "Done"];
const ITEM_TYPES = ["Story", "Task", "Bug"];
const PRIORITIES = ["None", "Low", "Medium", "High"];
const EPICS = ["", "", "", "Auth Overhaul", "Billing v2", "", "Channel Bay", "", "Mobile Polish", ""];

const CARD_TITLES = [
  "API Version Migration",
  "Refactor auth handshake on cold start",
  "Sprint planning tool — drag to reorder",
  "Channel Bay performance audit",
  "Reduce dashboard time-to-first-paint",
  "Fix duplicate webhook on retry",
  "Onboarding empty states",
  "Slack integration: card mention parser",
  "Export CSV from board view",
  "Color picker in card detail panel",
  "Keyboard shortcuts palette",
  "Search: weight by recency",
  "Comment threads — collapse long replies",
  "Card archive bin + recovery",
  "Move card animation jank on Safari",
  "Permissions: read-only board sharing",
  "Sprint burndown chart",
  "Mobile: long-press to open menu",
  "Tighten the empty board zero-state",
  "Right-click card menu",
  "Avatar uploads via drag",
  "Two-factor auth setup flow",
  "Billing: prorated upgrades",
  "Inactive workspace banner",
  "Email digest — weekly summary",
  "Refactor Realtime cursor presence",
  "Tag autocomplete in card detail",
  "Date picker: relative shortcuts",
  "Audit log for admins",
  "Trash-can icon hit area too small",
  "Webhooks: signing secret rotation",
  "Saved filters in sidebar",
  "Markdown paste preserves links",
  "Card drag preview ghost is laggy",
  "Sprint planning — capacity hint",
  "Redirect after invite accept is wrong",
  "Empty board video walkthrough",
  "Guest accounts read-only enforcement",
  "Templates: kanban / scrum / personal",
  "Push notifications iOS — re-enable",
  "Rate limiting on bulk move",
  "Dark mode pass for card detail",
  "Stale invite link auto-expiry",
  "Compact card density toggle",
  "Sprint label colors",
  "Card subscriber list sort",
  "Restore deleted card (24h grace)",
  "Custom emoji reactions",
  "Card link unfurl in chat",
  "Webhook delivery dashboard",
  "Archive board with confirmation",
];

// deterministic pseudo-random so the table is stable across renders
function mulberry32(seed) {
  return function() {
    let t = (seed += 0x6D2B79F5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function fmtDate(d) {
  const dd = String(d.getDate()).padStart(2, "0");
  const mons = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  const mm = mons[d.getMonth()];
  const yy = d.getFullYear();
  let h = d.getHours();
  const min = String(d.getMinutes()).padStart(2, "0");
  const ampm = h >= 12 ? "PM" : "AM";
  h = h % 12; if (h === 0) h = 12;
  return `${dd}/${mm}/${yy} ${String(h).padStart(2,"0")}:${min} ${ampm}`;
}

function isoOf(d) { return d.toISOString().slice(0,10); }

function buildCards() {
  const rand = mulberry32(7);
  const cards = [];

  // Window: late Jan 2026 → early Apr 2026 (matches screenshot dates)
  const start = new Date(2026, 0, 12, 9, 0);   // 12 Jan 2026
  const end   = new Date(2026, 3, 8, 18, 0);   // 8  Apr 2026
  const span  = end.getTime() - start.getTime();

  for (let i = 0; i < CARD_TITLES.length; i++) {
    const title = CARD_TITLES[i];
    const createdAt = new Date(start.getTime() + rand() * span * 0.85);
    const cycleHours = 6 + rand() * 24 * 18; // 6h .. ~18d
    const completedAt = new Date(createdAt.getTime() + cycleHours * 3600 * 1000);
    const status = (completedAt > end || rand() < 0.25)
      ? STATUSES[Math.floor(rand() * (STATUSES.length - 1))] // anything but Done
      : "Done";

    // Most cards single assignee; some have two (matching the row "Dhishan Kudwalli,Ebenezer Raja")
    const a1 = ASSIGNEES[Math.floor(rand() * ASSIGNEES.length)];
    const assignees = [a1];
    if (rand() < 0.18) {
      let a2 = ASSIGNEES[Math.floor(rand() * ASSIGNEES.length)];
      if (a2.name !== a1.name) assignees.push(a2);
    }

    const itemType = ITEM_TYPES[Math.floor(rand() * (rand() < 0.7 ? 1.6 : ITEM_TYPES.length))];
    const priority = PRIORITIES[Math.floor(rand() * (rand() < 0.55 ? 1 : PRIORITIES.length))];
    const epic     = EPICS[Math.floor(rand() * EPICS.length)];

    // Fibonacci-ish story points, weighted toward small
    const sp = [1, 2, 2, 3, 3, 3, 5, 5, 8, 13][Math.floor(rand() * 10)];
    cards.push({
      id: 100 + i,
      title,
      completedAt: status === "Done" ? completedAt : null,
      createdAt,
      createdBy: rand() < 0.85 ? "Ebenezer Raja" : ASSIGNEES[Math.floor(rand() * ASSIGNEES.length)].name,
      sprint: "Kanban Board",
      storyPoints: sp,
      assignees,
      status,
      epic,
      itemType,
      priority,
      comments: Math.floor(rand() * 6),
    });
  }

  // Sort newest-completed first (with nulls last)
  cards.sort((a, b) => {
    const at = a.completedAt ? a.completedAt.getTime() : 0;
    const bt = b.completedAt ? b.completedAt.getTime() : 0;
    return bt - at;
  });

  return cards;
}

const CARDS = buildCards();

// --- Activity timeline -----------------------------------------------------
// Synthesize an activity stream from the cards: created, moved, commented, completed.
function buildActivity() {
  const rand = mulberry32(91);
  const events = [];
  for (const c of CARDS) {
    events.push({
      kind: "created",
      at: c.createdAt,
      actor: c.createdBy,
      card: c,
    });
    // 0..2 status moves between created and completed
    const moves = Math.floor(rand() * 3);
    for (let m = 0; m < moves; m++) {
      const t = new Date(c.createdAt.getTime() + rand() * ((c.completedAt || c.createdAt).getTime() - c.createdAt.getTime()));
      const to = ["In Progress", "QA", "Ready to Deploy", "Bugs"][Math.floor(rand() * 4)];
      events.push({ kind: "moved", at: t, actor: c.assignees[0].name, card: c, to });
    }
    // comments
    for (let cm = 0; cm < c.comments; cm++) {
      const t = new Date(c.createdAt.getTime() + rand() * ((c.completedAt || c.createdAt).getTime() - c.createdAt.getTime()));
      events.push({
        kind: "commented",
        at: t,
        actor: c.assignees[Math.floor(rand() * c.assignees.length)].name,
        card: c,
      });
    }
    if (c.completedAt) {
      events.push({ kind: "completed", at: c.completedAt, actor: c.assignees[0].name, card: c });
    }
  }
  events.sort((a, b) => b.at.getTime() - a.at.getTime());
  return events;
}

const ACTIVITY = buildActivity();

window.FIZZY_DATA = { CARDS, ACTIVITY, ASSIGNEES, STATUSES, ITEM_TYPES, PRIORITIES, fmtDate, isoOf };
