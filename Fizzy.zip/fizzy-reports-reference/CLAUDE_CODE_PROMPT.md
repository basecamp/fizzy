# Fizzy — Reports Page (Claude Code build prompt)

Build a **Reports page** for the Fizzy kanban app, matching the existing Channel Bay board's visual style. The page lists every card on the board in a sortable table with filters, plus an Activity timeline tab, plus an `.xlsx` export.

A working hi-fi mock exists at `Reports.html` / `app.jsx` / `styles.css` / `data.js` — use it as the source of truth for layout, colors, typography, and component behavior. This prompt summarizes intent; the mock is canonical.

---

## 1. Stack & file layout

- React 18 + TypeScript (or plain JS — match the rest of the app).
- Stylesheet approach: whatever the rest of the Fizzy app uses (CSS modules / Tailwind / plain CSS). The mock uses plain CSS with custom properties — easy to port.
- New route: `/board/:boardId/reports` (or wherever Channel Bay lives + `/reports`).
- Components to create:
  - `ReportsPage` — top-level route component
  - `HeaderRule` — centered title with horizontal rules + side icon buttons (reuse from board if it already exists)
  - `FilterBar` — pill-shaped container holding filter chips, view tabs, export button
  - `AssigneeFilter` — multi-select chip with avatar popover
  - `DateRangeFilter` — chip with preset list + custom from/to inputs
  - `ViewTabs` — segmented "Cards table / Activity timeline" toggle
  - `KpiStrip` — 4 cards: scope / completed / in flight / avg cycle time
  - `CardsTable` — sortable, columns below
  - `ActivityTimeline` — events grouped by day
  - `ExportButton` — generates `.xlsx` via SheetJS

## 2. Entry point on the board page

Add a circular icon button to the board's top-right header chrome, **immediately to the left of the existing settings gear**. Use a bar-chart icon. Clicking it routes to the Reports page for the current board. Same size/border/hover styling as the gear button — just a different glyph.

## 3. Page layout (top → bottom)

1. **Top bar**: centered Fizzy logo + board switcher (reuse existing component)
2. **Header rule**: `[icon] ── Reports ── [icon]` — same treatment as "Channel Bay"
3. **Filter bar** (rounded pill, white bg, soft border, full-width up to ~1240px, centered):
   - `Assignee` chip (multi-select, avatar popover)
   - `Completed` date-range chip (presets: All time / Last 7 / 14 / 30 / 90 days / This sprint, plus custom from/to)
   - `Clear all filters` link (only when filters active)
   - **spacer**
   - `Cards table / Activity timeline` view tabs
   - `Export .xlsx` button (gold gradient, primary)
4. **KPI strip** (4-up grid): Cards in scope / Completed (% of scope) / In flight / Avg cycle time
5. **Content area**: either the table or the timeline based on the active tab

## 4. Cards table — columns (in order)

| Column        | Notes                                                              |
| ------------- | ------------------------------------------------------------------ |
| Completed On  | Mono font, "DD/Mon/YYYY HH:MM AM" format. `—` if not done.         |
| Created On    | Same format.                                                       |
| Card          | `#ID` (mono, muted) above the title (bold). Min-width 280px.       |
| Created by    | Plain text.                                                        |
| Story Points  | Small gold-pill with mono numeral. Centered, sortable numerically. |
| Assignee      | Avatar stack + comma-joined names.                                 |
| Status        | Colored pill (Done = green, In Progress = amber, QA = indigo, Bugs = red, Ready to Deploy = olive, Maybe? = brown, Not Now = gray). |
| Epic          | Blue tag if present, `—` otherwise.                                 |
| Item Type     | Pill (Story = blue, Task = brown, Bug = red).                       |
| Priority      | Pill (Low = gray, Medium = amber, High = red, None = `—`).          |

- All headers click to sort; clicking the active column flips direction.
- Default sort: `Completed On` desc.
- Sticky header on vertical scroll.
- Row hover: warm cream tint.

## 5. Activity timeline

Synthesize from card history. Four event types: `created`, `moved`, `commented`, `completed`. Group by day, with day headers ("Today", "Yesterday", or `Wednesday, 25 Mar 2026`). Each row:

```
[icon] [avatar] {actor} {verb} #{id} {title} [→ {newStatus}]?
       {timestamp} · cycle 18.3h (only for completed)
```

Icon colors: created = brown, moved = blue, commented = neutral, completed = green.

## 6. Filter behavior

- Filters apply to **both** views.
- Assignee filter matches if the card has any of the selected people OR (for activity) the actor is one of them.
- Date range filter is applied against `completedAt || createdAt` for cards, and `event.at` for activity.
- "All time" preset = no filter.

## 7. Export

- Library: [`xlsx`](https://www.npmjs.com/package/xlsx) (SheetJS) — `yarn add xlsx`.
- Three sheets:
  1. **Summary** — generated timestamp, active filters, totals (scope / completed / in flight / activity events).
  2. **Cards** — every column from the table + a computed `Cycle (hours)` column.
  3. **Activity** — Timestamp / Actor / Event / Card ID / Card / Detail.
- Filename: `fizzy-{board-slug}-{ISO-stamp}.xlsx`.
- Export respects active filters.
- Button shows a brief green "Exported" flash on success.

## 8. Design tokens (lift from `styles.css`)

```css
--bg:           #fdfcf8;   /* warm cream */
--bg-2:         #f6f1e6;
--paper:        #ffffff;
--ink:          #0e1726;
--ink-2:        #1f2a3d;
--ink-soft:     #5a6478;
--ink-mute:     #94978f;
--line:         #e8e0cc;
--line-2:       #efe9d9;
--brown:        #8a5a26;
--brown-2:      #a87a3d;
--gold:         #c9a06b;
--gold-soft:    #e9d6ad;
--bay-blue:     #2962e0;
--green:        #4f9a4a;
--red:          #c8423a;
--amber:        #d68a1c;
```

- Body font: **Geist** (300–900). Mono: **Geist Mono**.
- Heading 1: 800 weight, -0.025em letter-spacing, fluid 28→40px.
- Uppercase micro-labels: 10.5px, 700 weight, 0.09em letter-spacing, `--ink-mute`.
- Avatars: HSL gradient circle keyed off the user's hue, single capital initial, 1.5px white inner ring.

## 9. Data shape

```ts
type Card = {
  id: number;
  title: string;
  completedAt: Date | null;
  createdAt: Date;
  createdBy: string;
  storyPoints: 1 | 2 | 3 | 5 | 8 | 13;
  assignees: { name: string; initial: string; hue: number }[];
  status: "Not Now" | "Maybe?" | "In Progress" | "QA" | "Bugs" | "Ready to Deploy" | "Done";
  epic: string;        // empty string when none
  itemType: "Story" | "Task" | "Bug";
  priority: "None" | "Low" | "Medium" | "High";
  comments: number;
};

type ActivityEvent = {
  kind: "created" | "moved" | "commented" | "completed";
  at: Date;
  actor: string;
  card: Card;
  to?: string;          // only for "moved"
};
```

## 10. Acceptance checklist

- [ ] Reports icon button on board header → routes to Reports page.
- [ ] Header rule + filter bar match Channel Bay's visual rhythm.
- [ ] Both filters update table + timeline + KPI strip live.
- [ ] All 10 table columns render; all are sortable; default = Completed On desc.
- [ ] Story Points column shows numeric pill, sorts numerically.
- [ ] Activity timeline groups events by day with friendly day labels.
- [ ] Export downloads a 3-sheet `.xlsx` reflecting current filters.
- [ ] Empty states handled (no cards in scope, no activity).
- [ ] Responsive: KPI strip collapses 4 → 2 → 1 columns; filter bar wraps.
