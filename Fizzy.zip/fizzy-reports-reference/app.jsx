/* global React, ReactDOM */
const { useState, useMemo, useEffect, useRef } = React;
const FD = window.FIZZY_DATA;
const ALL_CARDS = FD.CARDS;
const ALL_ACTIVITY = FD.ACTIVITY;
const ROSTER = FD.ASSIGNEES;
const fmtDateStr = FD.fmtDate;
const isoStr = FD.isoOf;

/* ------------------------------------------------------------------ */
/* Logo + chrome                                                       */
/* ------------------------------------------------------------------ */

function FizzyLogo() {
  // Rainbow vertical stripes mirroring the kanban screenshot
  const stripes = ["#e83a3a", "#f6a93b", "#f6d83b", "#5cc879", "#3aa3e8", "#7c5bd8"];
  return (
    <div className="logo">
      <div className="logo__stripes" aria-hidden="true">
        {stripes.map((c, i) => (
          <span key={i} style={{ background: c }} />
        ))}
      </div>
      <span className="logo__word">Fizzy</span>
      <span className="logo__board">J</span>
      <svg width="10" height="10" viewBox="0 0 10 10" className="logo__caret"><path d="M2 4l3 3 3-3" stroke="currentColor" strokeWidth="1.4" fill="none" strokeLinecap="round" strokeLinejoin="round"/></svg>
    </div>
  );
}

function Avatar({ person, size = 28 }) {
  const a = typeof person === "string"
    ? ROSTER.find((x) => x.name === person) || { initial: person[0], hue: 32 }
    : person;
  const hue = a.hue ?? 32;
  return (
    <span
      className="avatar"
      style={{
        width: size,
        height: size,
        fontSize: Math.round(size * 0.42),
        background: `radial-gradient(circle at 30% 25%, hsl(${hue} 70% 78%) 0%, hsl(${hue} 55% 55%) 55%, hsl(${hue} 60% 40%) 100%)`,
      }}
      title={a.name || a}
    >{a.initial}</span>
  );
}

/* ------------------------------------------------------------------ */
/* Header w/ centered title and side rules                            */
/* ------------------------------------------------------------------ */

function HeaderRule({ title }) {
  return (
    <div className="rule">
      <button className="rule__icon" aria-label="Workspace">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>
      </button>
      <div className="rule__line" />
      <h1 className="rule__title">{title}</h1>
      <div className="rule__line" />
      <button className="rule__icon" aria-label="Settings">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>
      </button>
    </div>
  );
}

function TopBar() {
  return (
    <div className="topbar">
      <FizzyLogo />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Filter chips                                                        */
/* ------------------------------------------------------------------ */

function AssigneeFilter({ value, onChange }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    const off = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", off);
    return () => document.removeEventListener("mousedown", off);
  }, []);
  const toggle = (name) => {
    onChange(value.includes(name) ? value.filter((v) => v !== name) : [...value, name]);
  };
  const label = value.length === 0
    ? "Any assignee"
    : value.length === 1 ? value[0] : `${value.length} assignees`;

  return (
    <div className="chip-wrap" ref={ref}>
      <button
        className={`chip ${value.length ? "chip--active" : ""}`}
        onClick={() => setOpen((o) => !o)}
      >
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>
        <span className="chip__label">Assignee</span>
        <span className="chip__sep" />
        <span className="chip__value">{label}</span>
        {value.length > 0 && (
          <span className="chip__x" onClick={(e) => { e.stopPropagation(); onChange([]); }} role="button">×</span>
        )}
      </button>
      {open && (
        <div className="popover">
          {ROSTER.map((a) => {
            const active = value.includes(a.name);
            return (
              <button key={a.name} className={`popover__row ${active ? "is-active" : ""}`} onClick={() => toggle(a.name)}>
                <Avatar person={a} size={22} />
                <span className="popover__name">{a.name}</span>
                {active && <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4"><path d="M5 12l5 5L20 7"/></svg>}
              </button>
            );
          })}
          {value.length > 0 && (
            <button className="popover__clear" onClick={() => onChange([])}>Clear</button>
          )}
        </div>
      )}
    </div>
  );
}

function DateRangeFilter({ value, onChange }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    const off = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", off);
    return () => document.removeEventListener("mousedown", off);
  }, []);

  const presets = [
    { id: "all", label: "All time", days: null },
    { id: "7",   label: "Last 7 days", days: 7 },
    { id: "14",  label: "Last 14 days", days: 14 },
    { id: "30",  label: "Last 30 days", days: 30 },
    { id: "90",  label: "Last 90 days", days: 90 },
    { id: "ytd", label: "This sprint", days: 14 },
  ];

  const activePreset = presets.find((p) => p.id === value.preset);
  const label = value.preset === "custom"
    ? `${value.from} → ${value.to}`
    : (activePreset?.label || "All time");

  return (
    <div className="chip-wrap" ref={ref}>
      <button
        className={`chip ${value.preset !== "all" ? "chip--active" : ""}`}
        onClick={() => setOpen((o) => !o)}
      >
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8"><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/></svg>
        <span className="chip__label">Completed</span>
        <span className="chip__sep" />
        <span className="chip__value">{label}</span>
        {value.preset !== "all" && (
          <span className="chip__x" onClick={(e) => { e.stopPropagation(); onChange({ preset: "all" }); }} role="button">×</span>
        )}
      </button>
      {open && (
        <div className="popover popover--wide">
          {presets.map((p) => (
            <button
              key={p.id}
              className={`popover__row ${value.preset === p.id ? "is-active" : ""}`}
              onClick={() => { onChange({ preset: p.id }); setOpen(false); }}
            >
              <span className="popover__name">{p.label}</span>
              {value.preset === p.id && <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4"><path d="M5 12l5 5L20 7"/></svg>}
            </button>
          ))}
          <div className="popover__custom">
            <label>From <input type="date" value={value.from || ""} onChange={(e) => onChange({ preset: "custom", from: e.target.value, to: value.to || isoStr(new Date()) })} /></label>
            <label>To <input type="date" value={value.to || ""} onChange={(e) => onChange({ preset: "custom", from: value.from || "2026-01-01", to: e.target.value })} /></label>
          </div>
        </div>
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* KPI strip                                                           */
/* ------------------------------------------------------------------ */

function Kpi({ label, value, sub }) {
  return (
    <div className="kpi">
      <div className="kpi__label">{label}</div>
      <div className="kpi__value">{value}</div>
      {sub && <div className="kpi__sub">{sub}</div>}
    </div>
  );
}

function KpiStrip({ filtered }) {
  const total = filtered.length;
  const done = filtered.filter((c) => c.status === "Done").length;
  const cycleHours = filtered
    .filter((c) => c.status === "Done")
    .map((c) => (c.completedAt - c.createdAt) / 36e5);
  const avgCycle = cycleHours.length
    ? cycleHours.reduce((a, b) => a + b, 0) / cycleHours.length
    : 0;
  const inFlight = filtered.filter((c) => c.status !== "Done").length;
  const fmtCycle = (h) => h < 24 ? `${h.toFixed(1)}h` : `${(h / 24).toFixed(1)}d`;

  return (
    <div className="kpi-strip">
      <Kpi label="Cards in scope"  value={total}                sub="matching filters" />
      <Kpi label="Completed"        value={done}                 sub={total ? `${Math.round(done / total * 100)}% of scope` : "—"} />
      <Kpi label="In flight"        value={inFlight}             sub="not yet done" />
      <Kpi label="Avg. cycle time"  value={fmtCycle(avgCycle)}   sub="created → done" />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* View switcher                                                       */
/* ------------------------------------------------------------------ */

function ViewTabs({ value, onChange }) {
  return (
    <div className="tabs">
      <button className={`tab ${value === "table" ? "is-active" : ""}`} onClick={() => onChange("table")}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M9 4v16"/></svg>
        Cards table
      </button>
      <button className={`tab ${value === "timeline" ? "is-active" : ""}`} onClick={() => onChange("timeline")}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7"><circle cx="6" cy="6" r="2"/><circle cx="6" cy="18" r="2"/><path d="M6 8v8M10 6h10M10 18h10M10 12h7"/></svg>
        Activity timeline
      </button>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Cards table                                                         */
/* ------------------------------------------------------------------ */

const COLUMNS = [
  { id: "completedAt", label: "Completed On", sort: (c) => c.completedAt ? c.completedAt.getTime() : -Infinity },
  { id: "createdAt",   label: "Created On",   sort: (c) => c.createdAt.getTime() },
  { id: "title",       label: "Card",         sort: (c) => c.title.toLowerCase() },
  { id: "createdBy",   label: "Created by",   sort: (c) => c.createdBy },
  { id: "storyPoints", label: "Story Points", sort: (c) => c.storyPoints },
  { id: "assignees",   label: "Assignee",     sort: (c) => c.assignees[0]?.name || "" },
  { id: "status",      label: "Status",       sort: (c) => c.status },
  { id: "epic",        label: "Epic",         sort: (c) => c.epic || "" },
  { id: "itemType",    label: "Item Type",    sort: (c) => c.itemType },
  { id: "priority",    label: "Priority",     sort: (c) => c.priority },
];

function StatusPill({ status }) {
  const cls = status.toLowerCase().replace(/\W+/g, "-");
  return <span className={`pill pill--status pill--${cls}`}>{status}</span>;
}

function ItemTypePill({ type }) {
  return <span className={`pill pill--type pill--${type.toLowerCase()}`}>{type}</span>;
}

function PriorityPill({ p }) {
  if (p === "None") return <span className="muted">—</span>;
  return <span className={`pill pill--prio pill--${p.toLowerCase()}`}>{p}</span>;
}

function CardsTable({ rows }) {
  const [sortBy, setSortBy] = useState({ col: "completedAt", dir: "desc" });
  const sorted = useMemo(() => {
    const col = COLUMNS.find((c) => c.id === sortBy.col);
    if (!col) return rows;
    const arr = [...rows].sort((a, b) => {
      const av = col.sort(a), bv = col.sort(b);
      if (av < bv) return -1;
      if (av > bv) return 1;
      return 0;
    });
    if (sortBy.dir === "desc") arr.reverse();
    return arr;
  }, [rows, sortBy]);

  const handleSort = (id) => {
    setSortBy((s) => s.col === id ? { col: id, dir: s.dir === "asc" ? "desc" : "asc" } : { col: id, dir: "desc" });
  };

  return (
    <div className="table-wrap">
      <div className="table-scroll">
        <table className="cards-table">
          <thead>
            <tr>
              {COLUMNS.map((c) => (
                <th
                  key={c.id}
                  className={`th-${c.id} ${sortBy.col === c.id ? "is-sorted" : ""}`}
                  onClick={() => handleSort(c.id)}
                >
                  <span className="th__label">{c.label}</span>
                  <span className="th__sort">
                    {sortBy.col === c.id ? (sortBy.dir === "asc" ? "▲" : "▼") : "↕"}
                  </span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sorted.map((c) => (
              <tr key={c.id}>
                <td className="td-mono">{c.completedAt ? fmtDateStr(c.completedAt) : <span className="muted">—</span>}</td>
                <td className="td-mono">{fmtDateStr(c.createdAt)}</td>
                <td className="td-card">
                  <div className="td-card__id">#{c.id}</div>
                  <div className="td-card__title">{c.title}</div>
                </td>
                <td>{c.createdBy}</td>
                <td><span className="sp-tag">{c.storyPoints}</span></td>
                <td>
                  <div className="assignee-stack">
                    {c.assignees.map((a, i) => (
                      <Avatar key={i} person={a} size={22} />
                    ))}
                    <span className="assignee-stack__name">
                      {c.assignees.map((a) => a.name).join(", ")}
                    </span>
                  </div>
                </td>
                <td><StatusPill status={c.status} /></td>
                <td>{c.epic ? <span className="epic-tag">{c.epic}</span> : <span className="muted">—</span>}</td>
                <td><ItemTypePill type={c.itemType} /></td>
                <td><PriorityPill p={c.priority} /></td>
              </tr>
            ))}
            {sorted.length === 0 && (
              <tr><td colSpan={COLUMNS.length} className="empty">No cards match these filters.</td></tr>
            )}
          </tbody>
        </table>
      </div>
      <div className="table-foot">
        <span>{sorted.length} card{sorted.length === 1 ? "" : "s"}</span>
        <span className="muted">Sorted by {COLUMNS.find((c) => c.id === sortBy.col).label.toLowerCase()} · {sortBy.dir === "asc" ? "ascending" : "descending"}</span>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Activity timeline                                                   */
/* ------------------------------------------------------------------ */

function relTime(d, now) {
  const diff = (now.getTime() - d.getTime()) / 1000;
  if (diff < 60) return "just now";
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  if (diff < 86400 * 7) return `${Math.floor(diff / 86400)}d ago`;
  return fmtDateStr(d).split(" ").slice(0, 1).join(" ");
}

function dayKey(d) {
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}
function dayLabel(d, now) {
  const today = new Date(now); today.setHours(0,0,0,0);
  const yest = new Date(today); yest.setDate(yest.getDate() - 1);
  const day = new Date(d); day.setHours(0,0,0,0);
  if (day.getTime() === today.getTime()) return "Today";
  if (day.getTime() === yest.getTime()) return "Yesterday";
  return d.toLocaleDateString(undefined, { weekday: "long", day: "2-digit", month: "short", year: "numeric" });
}

function ActivityIcon({ kind }) {
  const map = {
    created:   { glyph: "+", cls: "act-icon--created" },
    moved:     { glyph: "→", cls: "act-icon--moved" },
    commented: { glyph: "💬", cls: "act-icon--commented", isEmoji: true },
    completed: { glyph: "✓", cls: "act-icon--completed" },
  };
  const m = map[kind];
  return <span className={`act-icon ${m.cls}`}>{m.glyph}</span>;
}

function ActivityRow({ ev }) {
  const verb = {
    created:   "created",
    moved:     "moved",
    commented: "commented on",
    completed: "completed",
  }[ev.kind];

  return (
    <div className="act-row">
      <ActivityIcon kind={ev.kind} />
      <div className="act-body">
        <div className="act-line">
          <Avatar person={ev.actor} size={18} />
          <span className="act-actor">{ev.actor}</span>
          <span className="act-verb">{verb}</span>
          <span className="act-card-id">#{ev.card.id}</span>
          <span className="act-card-title">{ev.card.title}</span>
          {ev.kind === "moved" && (
            <>
              <span className="act-verb">to</span>
              <StatusPill status={ev.to} />
            </>
          )}
        </div>
        <div className="act-meta">
          <span>{fmtDateStr(ev.at)}</span>
          {ev.kind === "completed" && (
            <span className="act-cycle">· cycle {((ev.card.completedAt - ev.card.createdAt) / 36e5).toFixed(1)}h</span>
          )}
        </div>
      </div>
    </div>
  );
}

function Timeline({ rows }) {
  // rows are events that pass filters
  const now = new Date(2026, 3, 8, 18, 30); // anchor "today" in the dataset
  const groups = useMemo(() => {
    const m = new Map();
    for (const ev of rows) {
      const k = dayKey(ev.at);
      if (!m.has(k)) m.set(k, []);
      m.get(k).push(ev);
    }
    return [...m.entries()];
  }, [rows]);

  return (
    <div className="timeline">
      {groups.length === 0 && <div className="empty">No activity matches these filters.</div>}
      {groups.map(([k, evs]) => (
        <div key={k} className="tl-day">
          <div className="tl-day-head">
            <span className="tl-day-label">{dayLabel(evs[0].at, now)}</span>
            <span className="tl-day-rule" />
            <span className="tl-day-count">{evs.length} event{evs.length === 1 ? "" : "s"}</span>
          </div>
          <div className="tl-day-body">
            {evs.map((ev, i) => <ActivityRow key={i} ev={ev} />)}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Export                                                              */
/* ------------------------------------------------------------------ */

function exportXlsx(filteredCards, filteredActivity, filterSummary) {
  const XLSX = window.XLSX;
  if (!XLSX) { alert("Export library failed to load."); return; }

  const cardRows = filteredCards.map((c) => ({
    "ID":            c.id,
    "Card":          c.title,
    "Completed On":  c.completedAt ? fmtDateStr(c.completedAt) : "",
    "Created On":    fmtDateStr(c.createdAt),
    "Created by":    c.createdBy,
    "Story Points":  c.storyPoints,
    "Assignee":      c.assignees.map((a) => a.name).join(", "),
    "Status":        c.status,
    "Epic":          c.epic || "",
    "Item Type":     c.itemType,
    "Priority":      c.priority,
    "Comments":      c.comments,
    "Cycle (hours)": c.completedAt
      ? +((c.completedAt - c.createdAt) / 36e5).toFixed(2)
      : "",
  }));

  const activityRows = filteredActivity.map((ev) => ({
    "Timestamp": fmtDateStr(ev.at),
    "Actor":     ev.actor,
    "Event":     ev.kind,
    "Card ID":   ev.card.id,
    "Card":      ev.card.title,
    "Detail":    ev.kind === "moved" ? `→ ${ev.to}` : "",
  }));

  const summaryRows = [
    ["Fizzy — Channel Bay — Reports export"],
    ["Generated", fmtDateStr(new Date())],
    [],
    ["Filters"],
    ["Assignees", filterSummary.assignees],
    ["Date range", filterSummary.dateRange],
    [],
    ["Totals"],
    ["Cards in scope", filteredCards.length],
    ["Activity events", filteredActivity.length],
    ["Completed", filteredCards.filter((c) => c.status === "Done").length],
    ["In flight", filteredCards.filter((c) => c.status !== "Done").length],
  ];

  const wb = XLSX.utils.book_new();
  const wsSummary  = XLSX.utils.aoa_to_sheet(summaryRows);
  const wsCards    = XLSX.utils.json_to_sheet(cardRows);
  const wsActivity = XLSX.utils.json_to_sheet(activityRows);

  // Column widths
  wsCards["!cols"] = [
    { wch: 6 },{ wch: 44 },{ wch: 22 },{ wch: 22 },{ wch: 18 },
    { wch: 14 },{ wch: 26 },{ wch: 14 },{ wch: 16 },{ wch: 12 },{ wch: 10 },{ wch: 10 },{ wch: 14 },
  ];
  wsActivity["!cols"] = [
    { wch: 22 },{ wch: 18 },{ wch: 14 },{ wch: 8 },{ wch: 44 },{ wch: 22 },
  ];
  wsSummary["!cols"] = [{ wch: 22 }, { wch: 36 }];

  XLSX.utils.book_append_sheet(wb, wsSummary,  "Summary");
  XLSX.utils.book_append_sheet(wb, wsCards,    "Cards");
  XLSX.utils.book_append_sheet(wb, wsActivity, "Activity");

  const stamp = new Date().toISOString().slice(0,16).replace(/[:T]/g, "-");
  XLSX.writeFile(wb, `fizzy-channel-bay-${stamp}.xlsx`);
}

function ExportButton({ cards, activity, filterSummary }) {
  const [flash, setFlash] = useState(false);
  const onClick = () => {
    exportXlsx(cards, activity, filterSummary);
    setFlash(true);
    setTimeout(() => setFlash(false), 1400);
  };
  return (
    <button className={`export-btn ${flash ? "is-flash" : ""}`} onClick={onClick}>
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 4v12M6 10l6 6 6-6M4 20h16"/></svg>
      <span>{flash ? "Exported" : "Export"}</span>
      <span className="export-btn__ext">.xlsx</span>
    </button>
  );
}

/* ------------------------------------------------------------------ */
/* Main app                                                            */
/* ------------------------------------------------------------------ */

function App() {
  const [view, setView] = useState("table");
  const [assignees, setAssignees] = useState([]);
  const [dateRange, setDateRange] = useState({ preset: "all" });

  // Filtering helpers
  const inDateRange = (d) => {
    if (!d) return dateRange.preset === "all" || dateRange.preset === undefined;
    if (dateRange.preset === "all") return true;
    if (dateRange.preset === "custom") {
      if (dateRange.from && d < new Date(dateRange.from)) return false;
      if (dateRange.to) {
        const to = new Date(dateRange.to); to.setHours(23,59,59);
        if (d > to) return false;
      }
      return true;
    }
    const days = { "7":7, "14":14, "30":30, "90":90, "ytd":14 }[dateRange.preset];
    if (!days) return true;
    const anchor = new Date(2026, 3, 8, 23, 59);
    const cutoff = new Date(anchor.getTime() - days * 86400 * 1000);
    return d >= cutoff;
  };

  const filteredCards = useMemo(() => {
    return ALL_CARDS.filter((c) => {
      if (assignees.length && !c.assignees.some((a) => assignees.includes(a.name))) return false;
      // For table: filter by completedAt when present, else createdAt — keeps "Last 7 days" intuitive
      const refDate = c.completedAt || c.createdAt;
      if (!inDateRange(refDate)) return false;
      return true;
    });
  }, [assignees, dateRange]);

  const filteredActivity = useMemo(() => {
    return ALL_ACTIVITY.filter((ev) => {
      if (assignees.length && !assignees.includes(ev.actor)
          && !ev.card.assignees.some((a) => assignees.includes(a.name))) return false;
      if (!inDateRange(ev.at)) return false;
      return true;
    });
  }, [assignees, dateRange]);

  const activeFilterCount = (assignees.length > 0 ? 1 : 0) + (dateRange.preset !== "all" ? 1 : 0);

  return (
    <div className="app">
      <TopBar />
      <HeaderRule title="Reports" />

      <div className="filterbar">
        <AssigneeFilter value={assignees} onChange={setAssignees} />
        <DateRangeFilter value={dateRange} onChange={setDateRange} />
        {activeFilterCount > 0 && (
          <button className="link-btn" onClick={() => { setAssignees([]); setDateRange({ preset: "all" }); }}>
            Clear all filters
          </button>
        )}
        <div className="filterbar__spacer" />
        <ViewTabs value={view} onChange={setView} />
        <ExportButton
          cards={filteredCards}
          activity={filteredActivity}
          filterSummary={{
            assignees: assignees.length ? assignees.join(", ") : "All",
            dateRange: dateRange.preset === "all" ? "All time"
              : dateRange.preset === "custom" ? `${dateRange.from || "—"} → ${dateRange.to || "—"}`
              : { "7":"Last 7 days","14":"Last 14 days","30":"Last 30 days","90":"Last 90 days","ytd":"This sprint" }[dateRange.preset],
          }}
        />
      </div>

      <KpiStrip filtered={filteredCards} />

      <div className="content">
        {view === "table"    && <CardsTable rows={filteredCards} />}
        {view === "timeline" && <Timeline   rows={filteredActivity} />}
      </div>

      <footer className="foot">
        Channel Bay · Kanban Board · {ALL_CARDS.length} cards · synthesized for design review
      </footer>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
